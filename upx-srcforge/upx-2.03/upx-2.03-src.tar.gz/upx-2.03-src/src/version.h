#define UPX_VERSION_HEX         0x020300        /* 02.03.00 */
#define UPX_VERSION_STRING      "2.03"
#define UPX_VERSION_STRING4     "2.03"
#define UPX_VERSION_DATE        "Nov 7th 2006"
#define UPX_VERSION_DATE_ISO    "2006-11-07"
#define UPX_VERSION_YEAR        "2006"
