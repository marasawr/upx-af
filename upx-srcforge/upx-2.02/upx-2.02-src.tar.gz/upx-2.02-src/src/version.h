#define UPX_VERSION_HEX         0x020200        /* 02.02.00 */
#define UPX_VERSION_STRING      "2.02"
#define UPX_VERSION_STRING4     "2.02"
#define UPX_VERSION_DATE        "Aug 13th 2006"
#define UPX_VERSION_DATE_ISO    "2006-08-13"
#define UPX_VERSION_YEAR        "2006"
