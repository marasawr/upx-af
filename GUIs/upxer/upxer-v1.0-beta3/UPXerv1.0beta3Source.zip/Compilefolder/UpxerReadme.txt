                         <<< Sourceforge.net >>>

		<<<� 2004 Sandytech Inc.>>>               
                                                  
                             UPXer - The UPX GUI Beta 3             
                copyright � 2004 Sandesh S Deshmukh.     
                                                    
            UPXer is a GUI for the existing UPX package      
                             which lacks one.                     
                                                   
            UPXer can be used out-of-the-box for compressing
            executables, which will result in reduction of file size
            of the executable (40-70 %), and can also be used 
            to decompress the compressed executable.
 
            The compressed executable will not experience any
            decrease in efficiency or increase in startup time!

            UPXer acts as a wrapper around upx, provide a GUI
            for the command-line upx.

            Inspite of being a great tool for compressing     
            executables , the UPX software lacks a GUI,     
            while other softwares of the same nature       
            have and are not free. so UPXer happened.  
                                                      
            UPXer will provide all the functionality      
            that upx is providing and will try to       
            support all the versions of upx.            
            The GUI will make it easy for people to use      
            UPX, which people dont,               
            due to its command line nature.           
                                                   
            UPXer will try to support all the options that   
            upx provides in the coming versions.        
                                                   
            This version of UPXer comes with upx 1.24w, 
            but u can change the "upx.exe" from the UPXer folder 
            with the version you want to use!


         UPXer comes with the GNU GPL(General Public License)
                      and so is totally open source.           
                                                    
       Current Members of the Development team           
                  at sourceforge.net for UPXer :-              
                                                    
          toanthrax(Anthraxer(Sandesh))[Developer-Admin]  
                              leflon [Tester]                    
                         the-man(Nick Burke) [Tester]            
                                                     
               Please use the bug-tracking system at           
               upxer summary page to report any bugs,        
                     or u can mail it to the admin.               
               Any input from users is always welcome.        
                                                  
                                                  
                                                   
               WEBSITE: http://upxer.sourceforge.net         
              SUMMARY PAGE: http://sourceforge.net/projects/upxer 
                           e-mail: toanthrax@users.sourceforge.net   
    
                           MADE IN INDIA.


>>>>>>How to use UPXer - The UPXer GUI Beta 3.<<<<<<

>>UPXer - The UPX GUI Beta 3 has some drastic improvements after the beta 2 release.
So now beta 2 looks like a cripple in front of beta 3.

>>beta 3 is now very simple to use, unlike the previous versions, only thing is that all the files 
provided with the beta 3 release remain in the UPXer folder, and are not removed.

>>beta 3 now has Drag-Drop support, so now you can drop any executable on the UPXer beta 3 window.
The best place however to drop the executable will be just above the multiline text box, that is on the right hand side of the Options button.

>>The UPX binary, that is "upx.exe" will be checked for its presence in the folder when the application starts,
and will be unable to function if the "upx.exe" is not present inthe UPXer folder.

>>you can however replace the "upx.exe" with the latest or previous version of "upx.exe"
under the following conditions:
1> the new "upx.exe" supports all the commands supported by upx 1.25w
2> the new "upx.exe" is a windows compatible version, i.e the version name ends with "w",
for example "upx 1.25w" where "w" indicates that it is meant for windows.
3>the new "upx.exe" if having any additional commands apart from those supported by upx 1.25w,
will not be supported or used from UPXer beta 3 but may be supported in the final version 1.0 release.

>>Once the executable is dropped in the beta 3 window or selected from the open file dialog box,
UPXer will test the executable for determining if the executable is suitable for operation by UPXer,
if yes, then which operation is possible. 

>That is if the selected executable is not operable by UPXer or is already packed/compressed by some
other Compression tool, then a message will be displayed that the executable cannot be operated on by 
UPXer. 

>If the executable is operable by UPXer, then a suitable operation will be recommended by UPXer,
based on the compression status of the executable, which can be either compressed/uncompressed.
A command button will be enabled to carry out the operation.

> After the operation is completed, the output from the "upx.exe" for the completed operation will be
visible in the rich text box.

> the executable on which any operation is performed is backed up by default by UPXer in the executable's
Application folder. If the executable is not working properly after any UPXer operation, then the original executable can be obtained by renaming the backup file to the original file name, which will simply involve the removing to the ".upxerbackup" extension from the backup file.

> if you dont want to backup the excutable then you can change the appropriate settings from the Options Dialog.

>the Options dialog box contains the most used options for the windows executables as well as the level of compression desierd while compressing an executable. you can change the appropriate options and UPXer will work accordingly.

>> UPXer beta 3 now supports all versions of windows

>>>>TO DO <<<<<

1> Support all the versions of upx.

2> Provide more options applicable for windows in the options dialog.

3>Improve the Drag-Drop function to accept file name from the shortcut of an executable!

4>Source Code -> Make use of more functions, than just writing the same code for the same operations.
