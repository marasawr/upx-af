                         <<< Sourceforge.net >>>               
                                                  
                             UPXer - The UPX GUI                
                copyright �2004 by Sandesh S Deshmukh     
                                                    
            UPXer is a GUI for the existing UPX package      
                             which lacks one.                     
                                                   
            Inspite of being a great tool for compressing     
             executables , the UPX software lacks a GUI,     
               while other softwares of the same nature       
           have and are not free. so UPXer should happen.  
                                                      
              UPXer will provide all the functionality      
               that upx is providing and will try to       
                  support all the versions of upx.            
              The GUI will make it easy for people to use      
                       UPX, which people dont,               
                    due to its command line nature.           
                                                   
            UPXer will try to support all the options that   
                    upx provides in the coming versions.        
                                                   
          This version of UPXer comes with upx 1.9 beta, 
     but u can change the "upx.exe" from the UPXer folder 
              with the version you want to use!


       UPXer comes with the GNU GPL(General Public License)
                   and so is totally open source.           
                                                    
       Current Members of the Development team           
                  at sourceforge.net for UPXer :-              
                                                    
          toanthrax(Anthraxer(Sandesh))[Developer-Admin]  
                              leflon [Tester]                    
                         the-man(Nick Burke) [Tester]            
                                                     
               Please use the bug-tracking system at           
               upxer summary page to report any bugs,        
                     or u can mail it to the admin.               
               Any input from users is always welcome.        
                                                  
                                                  
                                                   
               WEBSITE: http://upxer.sourceforge.net         
              SUMMARY PAGE: http://sourceforge.net/projects/upxer 
                           e-mail: toanthrax@users.sourceforge.net   
    
                                      MADE IN INDIA.                   
 


Project Information:

Project Descriptive Name:  UPXer - The UPX GUI
Project Unix Name:           upxer
CVS Server:                     cvs.sourceforge.net
Shell Server:                    shell.sourceforge.net
Web Server:                    upxer.sourceforge.net
