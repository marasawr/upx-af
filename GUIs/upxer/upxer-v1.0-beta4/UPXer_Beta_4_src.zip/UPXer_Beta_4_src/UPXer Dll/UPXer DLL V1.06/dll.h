#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#ifndef _DLL_H_
#define _DLL_H_

#if BUILDING_DLL
# define DLLIMPORT __declspec (dllexport)
#else /* Not BUILDING_DLL */
# define DLLIMPORT __declspec (dllimport)
#endif /* Not BUILDING_DLL */


//DLLIMPORT void HelloWorld (char *msg, short *chav);
//DLLIMPORT void HelloWorld (char *msg, short *chav);
//DLLIMPORT int HelloWorld2 ();

#endif /* _DLL_H_ */
