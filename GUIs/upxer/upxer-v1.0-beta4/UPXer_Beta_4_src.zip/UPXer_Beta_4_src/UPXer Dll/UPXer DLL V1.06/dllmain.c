
/* Replace "dll.h" with the name of your header */
#include "dll.h"

char TheScript[1024];
char FullResult[1024];
int DebugMode;
HANDLE mythread;
HANDLE con_out;
short CurrPos;

DWORD WINAPI CompressThread (LPVOID p);

void __stdcall DLLIMPORT GetFullResult (char *pimp)
//DLLIMPORT void HelloWorld (char *msg, short *chav)
{
    strcpy(pimp,FullResult);
}

void __stdcall DLLIMPORT GetCurrPos (short *pim)
//DLLIMPORT void HelloWorld (char *msg, short *chav)
{
    *pim=CurrPos;
}

//UPXer 
void __stdcall DLLIMPORT UPXerRunCommand (char *pimp,short debug)
//DLLIMPORT void HelloWorld (char *msg, short *chav)
{
    CurrPos=0;
    DebugMode=debug;
    strcpy(TheScript,pimp);
    
    DWORD id;
    mythread=CreateThread(NULL,0,CompressThread,0,0,&id);
}


BOOL APIENTRY DllMain (HINSTANCE hInst     /* Library instance handle. */ ,
                       DWORD reason        /* Reason this function is being called. */ ,
                       LPVOID reserved     /* Not used. */ )
{
    switch (reason)
    {
      case DLL_PROCESS_ATTACH:
        break;

      case DLL_PROCESS_DETACH:
        break;

      case DLL_THREAD_ATTACH:
        break;

      case DLL_THREAD_DETACH:
        break;
    }

    /* Returns TRUE on success, FALSE on failure */
    return TRUE;
}

DWORD WINAPI CompressThread (LPVOID p)
{     
  STARTUPINFO si={sizeof(si),};
  SECURITY_ATTRIBUTES sa={sizeof(sa),};
  SECURITY_DESCRIPTOR sd={0,};
  PROCESS_INFORMATION pi={0,};
  HANDLE newstdout=0;
  OSVERSIONINFO osv={sizeof(osv)};
  
  DWORD dwExit = STILL_ACTIVE;

  AllocConsole();
  con_out=GetStdHandle(STD_OUTPUT_HANDLE); 
  
  GetVersionEx(&osv);
  if (osv.dwPlatformId == VER_PLATFORM_WIN32_NT) 
    {
    InitializeSecurityDescriptor(&sd,SECURITY_DESCRIPTOR_REVISION);
    SetSecurityDescriptorDacl(&sd,TRUE,NULL,FALSE);
    sa.lpSecurityDescriptor = &sd;
    }
  else sa.lpSecurityDescriptor = NULL;
  sa.bInheritHandle = TRUE;
  GetStartupInfo(&si);
  si.dwFlags = STARTF_USESTDHANDLES;//|STARTF_USESHOWWINDOW;
  si.wShowWindow = SW_HIDE;
  si.hStdOutput = con_out;
  si.hStdError = newstdout;    

  if (!CreateProcess(NULL,TheScript,NULL,NULL,TRUE,CREATE_DEFAULT_ERROR_MODE,NULL,NULL,&si,&pi)) {
    //char buf[256];
    //wsprintf(buf,"Could not execute:\r\n %s.",TheScript);
    //FatalError(buf);
    CloseHandle(con_out);
    TidyUp();
    CurrPos=101;
    return 1;
  }
  if (DebugMode==0)
  {
  HideConsole();
  }
  sleep(50);

  while (dwExit == STILL_ACTIVE) 
  {   
    FindProgress();    
    sleep(50);
    GetExitCodeProcess(pi.hProcess, &dwExit);;
  }

  UpdateFullResult();

  CloseHandle(pi.hThread);
  CloseHandle(pi.hProcess);
  CloseHandle(con_out); 
  TidyUp();
  CurrPos=100;
}

//
int HideConsole()
{
  char ConsoleTitle[1024];
  HWND conhwnd;
  
  GetConsoleTitle(ConsoleTitle,1024);
  conhwnd=FindWindow(NULL,ConsoleTitle);
  ShowWindow(conhwnd,FALSE);    
}


int FindProgress()
{
  COORD CursorPos;
  char szBuf[1024];
  DWORD numread;
  int offset;
  int tmpoff;
  
  CursorPos.X=0;
  CursorPos.Y=6;

  ReadConsoleOutputCharacter(con_out,szBuf,80,CursorPos,&numread);
  szBuf[numread]=0;
  
  tmpoff=0;
  offset=0;
  
  while (offset==0)
    {
      if (szBuf[tmpoff]=='[')
        {  
          offset=tmpoff;
        }
      tmpoff++;
      if (tmpoff==80)
        {
          offset=80;
        }                                                                  
    }
  int j=0;
  int progcnt=0;
  for (j=offset;j<=numread;j++)
    {
      if (szBuf[j]=='*')
        {
          progcnt++;
        }                                           
    }
  CurrPos=(short) progcnt;
}

int TidyUp()
{
CloseHandle(mythread);
mythread=0;
FreeConsole();   
}

int UpdateFullResult()
{
  char szBuf[1024];
  DWORD numread;
  COORD CursorPos;

  CursorPos.X=0;
  CursorPos.Y=0;
  
  ReadConsoleOutputCharacter(con_out,szBuf,1024,CursorPos,&numread); 
  szBuf[numread]=0;
  strcpy(FullResult,szBuf);
}
