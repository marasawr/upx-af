<<< Sourceforge.net >>>

<<<� 2005 Sandytech Inc.>>>               
                                                  
UPXer - The UPX GUI Beta 5
             
Copyright � 2005 Sandesh S Deshmukh. 
Additional work for Beta 4&5 by Simon Nash   
                                                    
UPXer is a GUI for the existing UPX package which lacks one.                     
                                                   
UPXer can be used out-of-the-box for compressing executables, 
which will result in reduction of file size of the executable 
(40-70 %), and can also be used to decompress the compressed 
executable.
 
The compressed executable will not experience any decrease in 
efficiency or increase in startup time!

UPXer acts as a wrapper around upx, provide a GUI for the 
command-line upx.

Inspite of being a great tool for compressing executables, 
the UPX software lacks a GUI, while other softwares of the 
same nature have and are not free. so UPXer happened.  
                                                      
UPXer will provide all the functionality that upx is 
providing and will try to support all the versions of upx.            
The GUI will make it easy for people to use UPX, which 
people dont, due to its command line nature.           
                                                   
UPXer will try to support all the options that upx provides 
in the coming versions.        
                                                   
This version of UPXer comes with upx 1.25w, but you can change 
the "upx.exe" from the UPXer folder to the version you want 
to use!


UPXer comes with the GNU GPL(General Public License) and so 
is totally open source.           
                                                    
Current Members of the Development team           
at sourceforge.net for UPXer :-              
                                                    
toanthrax(Anthraxer(Sandesh))[Developer-Admin]
Simon Nash aka yetifoot[Developer]
leflon [Tester]                    
the-man(Nick Burke) [Tester]            
                                                     
Please use the bug-tracking system at upxer summary page 
to report any bugs, or u can mail it to the admin.               

Any input from users is always welcome.        
                                                  
WEBSITE: http://upxer.sourceforge.net         
SUMMARY PAGE: http://sourceforge.net/projects/upxer 
e-mail: toanthrax@users.sourceforge.net   
    
MADE IN INDIA.

>>>>>>How to use UPXer - The UPX GUI Beta 5.<<<<<<

>>Beta 5 Updates..

Inifile to save settings.
Best option for compression.
More Bug Trapping.

>>Beta 4 Updates..

No more reliance on C:\ as temp folder.
Console moved to dll to enable progress bar.
Other slight tweaks.

>>Beta 3 Updates..

Drag & Drop support
Check For upx.exe
Simpler Use
Tesing Of Files
