    UPX Tool V1.02

    Copyright (C) 2005 Simon Nash

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    This is free software, and you are welcome to redistribute it
    under certain conditions.

    UPX Tool comes with ABSOLUTELY NO WARRANTY.

    The full license can be found in 'COPYING' in the 'DOCS' folder.

    In Addition.
    Any executables compressed using this program may be distributed in 
    any manner, commercial or otherwise, on the condition that the UPX header
    is not modified in any way.
    For more information on this read 'UPXLICENSE' in the 'DOCS' folder.

    You can contact the author of this software by e-mail at:

    yetifoot@users.sourceforge.net

    You can obtain full sources for this program at :

    http://sourceforge.net/projects/upxer

    
    A lot of credit is due to the UPX team, whose excellent Packer made this
    possible.

    You can obtain full sources for the packer used in this program at:
    
    http://upx.sourceforge.net