//Copyright (C) 2005 Simon Nash

#include "globals.h"

//
int FindProgress()
{
  COORD CursorPos;
  char szBuf[1024];
  DWORD numread;
  int offset;
  int tmpoff;
  
  CursorPos.X=0;
  CursorPos.Y=6;

  ReadConsoleOutputCharacter(con_out,szBuf,80,CursorPos,&numread);
  
  tmpoff=0;
  offset=0;
  
  while (offset==0)
    {
      if (szBuf[tmpoff]=='[')
        {  
          offset=tmpoff;
        }
      tmpoff++;
      if (tmpoff==80)
        {
          offset=80;
        }                                                                  
    }
  int j=0;
  int progcnt=0;
  for (j=offset;j<offset+65;j++)
    {
      if (szBuf[j]=='*')
        {
          progcnt++;
        }                                           
    }
  
  SendMessage (GetDlgItem(hwndMainForm,IDC_PROGRESS),PBM_SETPOS,progcnt,0);
}
