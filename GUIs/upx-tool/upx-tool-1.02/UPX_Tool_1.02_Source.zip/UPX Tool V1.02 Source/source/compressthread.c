//Copyright (C) 2005 Simon Nash

#include "globals.h"
//

DWORD WINAPI CompressThread (LPVOID p)
{     
  STARTUPINFO si={sizeof(si),};
  SECURITY_ATTRIBUTES sa={sizeof(sa),};
  SECURITY_DESCRIPTOR sd={0,};
  PROCESS_INFORMATION pi={0,};
  HANDLE newstdout=0;
  OSVERSIONINFO osv={sizeof(osv)};
  
  DWORD dwExit = STILL_ACTIVE;

  AllocConsole();
  SetConsoleTitle("UPX Tool Console");
  con_out=GetStdHandle(STD_OUTPUT_HANDLE); 
  
  GetVersionEx(&osv);
  if (osv.dwPlatformId == VER_PLATFORM_WIN32_NT) 
    {
    InitializeSecurityDescriptor(&sd,SECURITY_DESCRIPTOR_REVISION);
    SetSecurityDescriptorDacl(&sd,TRUE,NULL,FALSE);
    sa.lpSecurityDescriptor = &sd;
    }
  else sa.lpSecurityDescriptor = NULL;
  sa.bInheritHandle = TRUE;
  GetStartupInfo(&si);
  si.dwFlags = STARTF_USESTDHANDLES;//|STARTF_USESHOWWINDOW;
  si.wShowWindow = SW_HIDE;
  si.hStdOutput = con_out;
  si.hStdError = newstdout;    

  if (!CreateProcess(NULL,TheScript,NULL,NULL,TRUE,CREATE_DEFAULT_ERROR_MODE,NULL,NULL,&si,&pi)) {
    char buf[256];
    wsprintf(buf,resstr14);//"Could not create process."
    FatalError(buf);
    CloseHandle(con_out);
    PostMessage(hwndMainForm,WM_MAKEUPX_PROCESSCOMPLETE,0,0);
    return 1;
  }
  if (Opts.ShowConsole==0)
  {
    HideConsole();
  }
  sleep(50);

  while (dwExit == STILL_ACTIVE) 
  {   
    FindProgress();    
    sleep(50);
    GetExitCodeProcess(pi.hProcess, &dwExit);;
  }

  CloseHandle(pi.hThread);
  CloseHandle(pi.hProcess);
  CloseHandle(con_out); 
  PostMessage(hwndMainForm,WM_MAKEUPX_PROCESSCOMPLETE,0,0);
}

//
int HideConsole()
{
  char ConsoleTitle[1024];
  HWND conhwnd;
  
  GetConsoleTitle(ConsoleTitle,1024);
  conhwnd=FindWindow(NULL,ConsoleTitle);
  if (conhwnd!=hwndMainForm)
  {
  ShowWindow(conhwnd,FALSE);    
  }
  else
  {
  ErrorBox(resstr4); //There Was A Problem Finding Console  
  }
}
