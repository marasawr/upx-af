//Copyright (C) 2005 Simon Nash


#include "globals.h"

//
int FatalError(LPSTR Caption)
{
  MessageBox (hwndMainForm,Caption,APP_SHORTTITLE,MB_OK|MB_ICONSTOP);
  PostQuitMessage(0);   
}

//
int ErrorBox(LPSTR Caption)
{
  MessageBox (hwndMainForm,Caption,APP_SHORTTITLE,MB_OK|MB_ICONSTOP);  
}

//
int ShowLabels()
{
LOGFONT lf;
HDC frmDC;
HFONT frmFont;

SystemParametersInfo(SPI_GETICONTITLELOGFONT, sizeof(lf), &lf, 0);
frmDC=GetDC(hwndMainForm);
lf.lfHeight = -MulDiv(10, GetDeviceCaps(frmDC, LOGPIXELSY), 72);
lf.lfWeight = 300;
strcpy(lf.lfFaceName,"Courier New");  
frmFont = CreateFontIndirect (&lf); 
SetTextColor(frmDC,MyColWhite);
SelectObject(frmDC,frmFont);
SetBkMode(frmDC,TRANSPARENT);
TextOut(frmDC,35,115,resstr15,strlen(resstr15));//"Compress"
TextOut(frmDC,35,138,resstr16,strlen(resstr16));//"Decompress"
TextOut(frmDC,195,10,resstr1,strlen(resstr1));//"Ultimate EXE Packer"
TextOut(frmDC,195,25,resstr2,strlen(resstr2));//"GUI Version by Simon Nash"
TextOut(frmDC,195,40,resstr3,strlen(resstr3));//"V1.02 Copyright 2005"
TextOut(frmDC,10,195,StatusMsg,strlen(StatusMsg));
ReleaseDC(hwndMainForm,frmDC);
}

//
int SetStatusText(LPSTR OutText)
{
RECT r;
strcpy(StatusMsg,OutText);
r.left=10;
r.right=410;
r.top=195;
r.bottom=215;
InvalidateRect(hwndMainForm,&r,TRUE); 
}

	
