//Copyright (C) 2005 Simon Nash

#include "globals.h"

//
int CreateObjects(HWND hwndOwner, LPARAM lParam)
{
  HWND tmphwnd;
  //LPSTR tmpstr;
  char tmpstr2[1024];
  LPSTR dufus;
  tmphwnd = CreateWindowEx (
    0,
    "STATIC",
    "TITLEBMP",
    WS_VISIBLE|WS_CHILD|SS_BITMAP,
    10,  10,  175,  56,
    hwndOwner,
    (HMENU) IDC_MAINBMP,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );

  tmphwnd = CreateWindowEx (
    0,
    "STATIC",
    "",
    WS_VISIBLE|WS_CHILD|SS_WHITEFRAME,
    10,  110,  130,  50,
    hwndOwner,
    (HMENU) IDC_FRAME1,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );

  tmphwnd = CreateWindowEx (
    0,
    "BUTTON",
    "",
    WS_VISIBLE|WS_CHILD|BS_AUTORADIOBUTTON,
    15,  111,  15,  24,
    hwndOwner,
    (HMENU) IDC_OPTCOMP,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  SendMessage(tmphwnd,BM_SETCHECK, 1,0);
  snChangeObjectFont(hwndOwner,tmphwnd,"Courier New",10,0);
  
  tmphwnd = CreateWindowEx (
    0,
    "BUTTON",
    "",
    WS_VISIBLE|WS_CHILD|BS_AUTORADIOBUTTON,
    15,  135,  15,  24,
    hwndOwner,
    (HMENU) IDC_OPTDECOMP,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  snChangeObjectFont(hwndOwner,tmphwnd,"Courier New",10,0);
  
  tmphwnd = CreateWindowEx (
    WS_EX_CLIENTEDGE,
    "EDIT", 
    resstr17,//"{FILENAME AND PATH HERE}"
    WS_VISIBLE|WS_CHILD|ES_LEFT|ES_AUTOHSCROLL,
    10,  80,  390,  22,
    hwndOwner,
    (HMENU) IDC_FILEEDIT,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  snChangeObjectFont(hwndOwner,tmphwnd,"Courier New",10,0);
  if (!AppInfo.CMDLine[0]==0)
  {
  strncpy(tmpstr2,AppInfo.CMDLine,strlen(AppInfo.CMDLine)-1);
  tmpstr2[strlen(AppInfo.CMDLine)-1]=0;
  dufus=strchr(tmpstr2,'"')+1;
  SetWindowText (tmphwnd,dufus);  
  }
  
  
  tmphwnd = CreateWindowEx (
    0,
    "BUTTON",
    "...",
    WS_VISIBLE|WS_CHILD,
    405,  80,  25,  22,
    hwndOwner,
    (HMENU) IDC_BROWSEBUTTON,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  
  tmphwnd = CreateWindowEx (
    0,
    "BUTTON",
    resstr18,//"Options"
    WS_VISIBLE|WS_CHILD,
    320,  110,  110,  22,
    hwndOwner,
    (HMENU) IDC_OPTIONSBUTTON,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  snChangeObjectFont(hwndOwner,tmphwnd,"Courier New",10,0);
    
  tmphwnd = CreateWindowEx (
    0,
    "BUTTON",
    resstr19, //"About"
    WS_VISIBLE|WS_CHILD,
    320,  138,  110,  22,
    hwndOwner,
    (HMENU) IDC_ABOUTBUTTON,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  snChangeObjectFont(hwndOwner,tmphwnd,"Courier New",10,0);
    
  tmphwnd = CreateWindowEx (
    0,
    "BUTTON",
    resstr20, //"GO!"
    WS_VISIBLE|WS_CHILD,
    150,  110,  160,  50,
    hwndOwner,
    (HMENU) IDC_GOBUTTON,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  snChangeObjectFont(hwndOwner,tmphwnd,"Courier New",22,1);
  
  tmphwnd = CreateWindowEx (
    WS_EX_CLIENTEDGE,
    "msctls_progress32",
    "",
    WS_CHILD|WS_VISIBLE,
    10,  170,  420,  15,
    hwndOwner,
    (HMENU) IDC_PROGRESS,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  ); 
  SendMessage (tmphwnd,PBM_SETRANGE,0,MAKELPARAM(0, 64));
  
}
