//Copyright (C) 2005 Simon Nash
//Credit due to NSIS team for snCheckIfFileExists function

#include "globals.h"

//
void snCenterWindowOnScreen(HWND hwnd)
{
  RECT r;
  
    GetWindowRect(hwnd,&r); 
    MoveWindow(
      hwnd,
      (GetSystemMetrics(SM_CXSCREEN)/2) - ((r.right-r.left)/2),
      (GetSystemMetrics(SM_CYSCREEN)/2) - ((r.bottom-r.top)/2),
      (r.right-r.left),
      (r.bottom-r.top),
      TRUE
      );
}

//
DWORD snGetFileSize(LPSTR filename)
{
  HANDLE FileHandle;
  DWORD lowo;
  DWORD higho;
  DWORD filesize;
  
    FileHandle=CreateFile(
      filename,
      GENERIC_READ,
      FILE_SHARE_READ,NULL,
      OPEN_EXISTING,
      FILE_ATTRIBUTE_NORMAL,NULL
      );
    higho=0;
    lowo=GetFileSize(FileHandle,&higho);	 

      if (higho == 0) 
        {
          filesize=lowo;
        }
      else
        {
          //File is too big.
          filesize=0;
        }
    CloseHandle(FileHandle);
    
    return filesize;
}

//
void snBeautifyFileSize(DWORD filesize, LPSTR buffer)
{
  float tmpfilesize;
  char tmpbuf[1024];

    tmpfilesize=(FLOAT)filesize;

      if (tmpfilesize>1024)
        {
          tmpfilesize=tmpfilesize/1024;
            if (tmpfilesize>1024)
              {
                tmpfilesize=tmpfilesize/1024;
                sprintf(tmpbuf,"%1.2f",tmpfilesize);
                strcat(tmpbuf," MB.");
              } 
            else
              {
                sprintf(tmpbuf,"%1.0f",tmpfilesize);
                strcat(tmpbuf," KB.");
              }
        }
      else
        {
          wsprintf(tmpbuf,"%4.4f",tmpfilesize);
          strcat(tmpbuf," Bytes.");
        }
        
    strcpy(buffer,tmpbuf);   
}

//
void snForceWindowToTop(HWND hwnd)
{
  SetWindowPos(hwnd,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);    
}

//
void snUnForceWindowToTop(HWND hwnd)
{
  SetWindowPos(hwnd,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);    
}

//
void snResizeClientArea(HWND hwnd,int NewClientWidth,int NewClientHeight)
{
  RECT r;
  RECT r2;
  
    GetWindowRect(hwnd,&r);
    GetClientRect(hwnd,&r2);
        
    MoveWindow(
      hwnd,
      r.left,
      r.top,
      NewClientWidth+((r.right-r.left)-(r2.right-r2.left)),
      NewClientHeight+((r.bottom-r.top)-(r2.bottom-r2.top)),
      TRUE
      );                    
}

//
void snChangeObjectFont(HWND hwndForm, HWND hwndObj, LPSTR strFace, int fontsize, int fontbold)
{
  LOGFONT lf;
  HDC frmDC;

    SystemParametersInfo(SPI_GETICONTITLELOGFONT, sizeof(lf), &lf, 0);
    frmDC=GetDC(hwndForm);
    lf.lfHeight = -MulDiv(fontsize, GetDeviceCaps(frmDC, LOGPIXELSY), 72);

      if (fontbold==0)
        {
          lf.lfWeight = 300;
        }
      else
        {
          lf.lfWeight = 700;
        }

    strcpy(lf.lfFaceName,strFace);  
    SendMessage(hwndObj,WM_SETFONT, (WPARAM)CreateFontIndirect (&lf), MAKELPARAM(TRUE, 0));
}

//
int snCheckIfFileExists(char *buf)
{
  HANDLE h;
  static WIN32_FIND_DATA fd;
  // Avoid a "There is no disk in the drive" error box on empty removable drives
  SetErrorMode(SEM_NOOPENFILEERRORBOX | SEM_FAILCRITICALERRORS);
  h = FindFirstFile(buf,&fd);
  SetErrorMode(0);
  if (h != INVALID_HANDLE_VALUE)
  {
    FindClose(h);
    return 1;
  }
  return 0;
}
