//Copyright (C) 2005 Simon Nash

#include "globals.h"

BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)                  /* handle the messages */
    {
        case WM_INITDIALOG:
            OptsDlg_Init(hwndDlg);
            break;
        case WM_COMMAND:
            if (LOWORD(wParam)==IDC_DLGOK)
               {
                 OptsDlg_Ok_Click(hwndDlg);
               }
               
            if (LOWORD(wParam)==IDC_DLGCANCEL)
               {
                 EnableWindow(hwndMainForm,1);                         
                 DestroyWindow(hwndDlg);                 
               }
               
            if (LOWORD(wParam)==IDC_DLGCOMPBEST)
               {
                                                
                 if (SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPBEST),BM_GETCHECK,0,0)==1)
                  {
                    SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPBEST),BM_SETCHECK, 1,0);
                    EnableWindow(GetDlgItem(hwndDlg, IDC_DLGTRACKER),0);
                    SetWindowText(GetDlgItem(hwndDlg,IDC_DLGLEVELLABEL),resstr21);
                  }  
                 else
                  {
                    char tmplev[25];
                    wsprintf(tmplev,resstr22,SendMessage(GetDlgItem(hwndDlg,IDC_DLGTRACKER),TBM_GETPOS,0,0));
                    strcat(tmplev,"             ");
                    SetWindowText(GetDlgItem(hwndDlg,IDC_DLGLEVELLABEL),tmplev);                                                           
                  }                                 
                                                
                                                
                                                
                 EnableWindow(GetDlgItem(hwndDlg,IDC_DLGTRACKER),1-(SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPBEST),BM_GETCHECK,0,0)));                                         
               }
            break;
            
        case WM_HSCROLL:
            if (((HWND) lParam)==(GetDlgItem(hwndDlg, IDC_DLGTRACKER)))
            {     
                 if (SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPBEST),BM_GETCHECK,0,0)==1)
                  {
                    SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPBEST),BM_SETCHECK, 1,0);
                    EnableWindow(GetDlgItem(hwndDlg, IDC_DLGTRACKER),0);
                    SetWindowText(GetDlgItem(hwndDlg,IDC_DLGLEVELLABEL),resstr21);
                  }  
                 else
                  {
                    char tmplev[25];
                    wsprintf(tmplev,resstr22,SendMessage(GetDlgItem(hwndDlg,IDC_DLGTRACKER),TBM_GETPOS,0,0));
                    strcat(tmplev,"             ");
                    SetWindowText(GetDlgItem(hwndDlg,IDC_DLGLEVELLABEL),tmplev);                                                           
                  }  
            }     
            break;
        case WM_CLOSE:
               EnableWindow(hwndMainForm,1);                         
               DestroyWindow(hwndDlg);             
            break;
    }
    return 0;     
}
