//Copyright (C) 2005 Simon Nash

#include "globals.h"

//
void LoadResourceStrings(HINSTANCE hInstance)
{
  LoadString(hInstance,8001,resstr1,1024);
  LoadString(hInstance,8002,resstr2,1024);
  LoadString(hInstance,8003,resstr3,1024);
  LoadString(hInstance,8004,resstr4,1024);
  LoadString(hInstance,8005,resstr5,1024);
  LoadString(hInstance,8006,resstr6,1024);
  LoadString(hInstance,8007,resstr7,1024);
  LoadString(hInstance,8008,resstr8,1024);
  LoadString(hInstance,8009,resstr9,1024);
  LoadString(hInstance,8010,resstr10,1024);
  LoadString(hInstance,8011,resstr11,1024);
  LoadString(hInstance,8012,resstr12,1024);
  LoadString(hInstance,8013,resstr13,1024);
  LoadString(hInstance,8014,resstr14,1024);
  LoadString(hInstance,8015,resstr15,1024);
  LoadString(hInstance,8016,resstr16,1024);
  LoadString(hInstance,8017,resstr17,1024);
  LoadString(hInstance,8018,resstr18,1024);
  LoadString(hInstance,8019,resstr19,1024);
  LoadString(hInstance,8020,resstr20,1024);
  LoadString(hInstance,8021,resstr21,1024);
  LoadString(hInstance,8022,resstr22,1024);
  LoadString(hInstance,8023,resstr23,1024);
  LoadString(hInstance,8024,resstr24,1024);
  LoadString(hInstance,8025,resstr25,1024);
}

//
void FillAppInfo(HINSTANCE hInstance, LPSTR lpszArgument)
{
  char tmp[1024];
  
    //ModuleFullPath
    GetModuleFileName(NULL,AppInfo.ModuleFullPath,1024);
  
    //ModuleName
    strcpy(AppInfo.ModuleName, strrchr(AppInfo.ModuleFullPath,'\\')+1);
    
    //ModulePath
    strncpy(tmp,AppInfo.ModuleFullPath,strlen(AppInfo.ModuleFullPath)-strlen(AppInfo.ModuleName));
    tmp[strlen(AppInfo.ModuleFullPath)-strlen(AppInfo.ModuleName)]='\0';
    strcpy(AppInfo.ModulePath,tmp);
    
    //hInstance
    AppInfo.hInstance=hInstance;
    
    //CMDLine
    strcpy(AppInfo.CMDLine,lpszArgument);
}

//
void CheckForUPX()
{
  char strpath[1024];
  
    strcpy (strpath,AppInfo.ModulePath);
    strcat (strpath,"bin\\upx.exe");
      if (!snCheckIfFileExists(strpath))
        {
          FatalError (resstr11);  //"No UPX.exe found in BIN folder.  Exiting Program."             
        }
}

//
void InitProg(HINSTANCE hThisInstance, LPSTR lpszArgument)
{
  static HINSTANCE hRichEditDLL = 0;

    InitCommonControls();
    FillAppInfo(hThisInstance,lpszArgument); 
    ReadINIFile();
    LoadResourceStrings(hThisInstance);
    if (!hRichEditDLL) hRichEditDLL= LoadLibrary("RichEd32.dll");
    CheckForUPX();     
}

