//Copyright (C) 2005 Simon Nash

#include "globals.h"

int ReadINIFile()
{
char tmp[256];
char inifile[1024];

strcpy (inifile,AppInfo.ModulePath);
strcat (inifile,"UPXTool.ini");

//GetPrivateProfileString(Section, SubSection, Default, tmp, 255, FileName) 
GetPrivateProfileString("Options", "CompressExports", "1", tmp, 255,inifile);
Opts.CompressExports=atoi(tmp);
GetPrivateProfileString("Options", "CompressIcons", "1", tmp, 255,inifile);
Opts.CompressIcons=atoi(tmp);
GetPrivateProfileString("Options", "CompressResources", "1", tmp, 255,inifile);
Opts.CompressResources=atoi(tmp);   
GetPrivateProfileString("Options", "StripRelocs", "1", tmp, 255,inifile);
Opts.StripRelocs=atoi(tmp);
GetPrivateProfileString("Options", "CompLevel", "9", tmp, 255,inifile);
Opts.CompLevel=atoi(tmp); 
GetPrivateProfileString("Options", "CompBest", "1", tmp, 255,inifile);
Opts.CompBest=atoi(tmp);
GetPrivateProfileString("Options", "AlwaysOnTop", "0", tmp, 255,inifile);
Opts.AlwaysOnTop=atoi(tmp);
GetPrivateProfileString("Options", "AutoStart", "0", tmp, 255,inifile);
Opts.AutoStart=atoi(tmp);
GetPrivateProfileString("Options", "ShowConsole", "0", tmp, 255,inifile);
Opts.ShowConsole=atoi(tmp);
GetPrivateProfileString("Options", "Backup", "0", tmp, 255,inifile);
Opts.Backup=atoi(tmp);          
}

int SaveINIFile()
{
char tmp[256];
char inifile[1024];

strcpy (inifile,AppInfo.ModulePath);
strcat (inifile,"UPXTool.ini");

wsprintf(tmp,"%i",Opts.CompressExports);
WritePrivateProfileString ("Options", "CompressExports", tmp, inifile);

wsprintf(tmp,"%i",Opts.CompressIcons);
WritePrivateProfileString ("Options", "CompressIcons", tmp, inifile);

wsprintf(tmp,"%i",Opts.CompressResources);
WritePrivateProfileString ("Options", "CompressResources", tmp, inifile);

wsprintf(tmp,"%i",Opts.StripRelocs);
WritePrivateProfileString ("Options", "StripRelocs", tmp, inifile);

wsprintf(tmp,"%i",Opts.CompLevel);
WritePrivateProfileString ("Options", "CompLevel", tmp, inifile);

wsprintf(tmp,"%i",Opts.CompBest);
WritePrivateProfileString ("Options", "CompBest", tmp, inifile);

wsprintf(tmp,"%i",Opts.AlwaysOnTop);
WritePrivateProfileString ("Options", "AlwaysOnTop", tmp, inifile);

wsprintf(tmp,"%i",Opts.AutoStart);
WritePrivateProfileString ("Options", "AutoStart", tmp, inifile);

wsprintf(tmp,"%i",Opts.ShowConsole);
WritePrivateProfileString ("Options", "ShowConsole", tmp, inifile);

wsprintf(tmp,"%i",Opts.Backup);
WritePrivateProfileString ("Options", "Backup", tmp, inifile);       
}
