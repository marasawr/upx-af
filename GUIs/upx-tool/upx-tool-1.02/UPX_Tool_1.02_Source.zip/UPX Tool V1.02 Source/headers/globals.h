//Copyright (C) 2005 Simon Nash

#include <windows.h>
#include <richedit.h>
#include <commctrl.h>
#include <commdlg.h>
#include <winuser.h>

#define WM_MAKEUPX_PROCESSCOMPLETE (WM_USER+1001)

#define mdCompress   0
#define mdDecompress 1

#define APP_SHORTTITLE "UPX"
#define APP_LONGTITLE  "UPX Tool" 

#define IDC_MAINBMP              7001
#define IDC_FRAME1               7002
#define IDC_OPTCOMP              7003
#define IDC_OPTDECOMP            7004
#define IDC_FILEEDIT             7005
#define IDC_BROWSEBUTTON         7006
#define IDC_ABOUTBUTTON          7007
#define IDC_OPTIONSBUTTON        7008
#define IDC_GOBUTTON             7009
#define IDC_PROGRESS             7010
#define IDC_DLGOK                7011
#define IDC_DLGCANCEL            7012
#define IDC_DLGCOMPRESSEXPORTS   7013
#define IDC_DLGCOMPRESSICONS     7014
#define IDC_DLGCOMPRESSRESOURCES 7015
#define IDC_DLGTRACKER           7016
#define IDC_DLGSTRIPRELOCS       7017
#define IDC_DLGCOMPBEST          7018
#define IDC_DLGALWAYSONTOP       7019
#define IDC_DLGLEVELLABEL        7020
#define IDC_DLGAUTOSTART         7021
#define IDC_DLGSHOWCONSOLE       7022
#define IDC_DLGBACKUP            7023

#define MyColWhite RGB(255,255,255)
#define MyColBlack RGB(0,0,0)
#define MyColRed RGB(255,0,0)
#define MyColGreen RGB(0,255,0)
#define MyColBlue RGB(0,0,255)

#define MyBackCol RGB(0,0,66)

typedef struct AppInfoType {
  char ModuleFullPath[1024];
  char ModuleName[1024];
  char ModulePath[1024];
  HINSTANCE hInstance;
  char CMDLine[1024];
} NAPPINFOTYPE;

typedef struct UPXOptsType {
  int CompressExports;
  int CompressIcons;
  int CompressResources;
  int StripRelocs;
  int CompLevel;
  int CompBest;
  int AlwaysOnTop;
  int AutoStart;
  int ShowConsole;
  int Backup;
} NUPXOptsType;

NAPPINFOTYPE AppInfo;
NUPXOptsType Opts;

HWND hwndMainForm;
HANDLE mythread;
HANDLE con_out;

char TheScript[1024];
char StatusMsg[1024];

char WorkFile[1024];
DWORD oldsize;
DWORD newsize;

char resstr1[1024];
char resstr2[1024];
char resstr3[1024];
char resstr4[1024];
char resstr5[1024];
char resstr6[1024];
char resstr7[1024];
char resstr8[1024];
char resstr9[1024];
char resstr10[1024];
char resstr11[1024];
char resstr12[1024];
char resstr13[1024];
char resstr14[1024];
char resstr15[1024];
char resstr16[1024];
char resstr17[1024];
char resstr18[1024];
char resstr19[1024];
char resstr20[1024];
char resstr21[1024];
char resstr22[1024];
char resstr23[1024];
char resstr24[1024];
char resstr25[1024];

DWORD WINAPI CompressThread (LPVOID p);
BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
int ErrorBox(LPSTR Caption);
