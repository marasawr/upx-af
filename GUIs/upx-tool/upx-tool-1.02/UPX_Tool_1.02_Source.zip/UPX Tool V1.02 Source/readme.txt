This is a Dev-C++ Project.

You can get Dev-C++ from www.bloodshed.net

This uses the popular mingw compiler.

Credits to: 
The creators of UPX.
To Sandesh S. Deshmukh, For the original idea.
To NSIS for one of their functions, and the installer.

yetifoot@users.sourceforge.net