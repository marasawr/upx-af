//Copyright (C) 2005 Simon Nash

#include "globals.h"

//
int BuildCmd(LPSTR workfile)
{
  int Opt1Val;
  DWORD retval;
  char tmpPath[1024]; 
 
     
  Opt1Val=SendMessage(GetDlgItem(hwndMainForm,IDC_OPTCOMP),BM_GETCHECK,0,0);
              
    if (Opt1Val==BST_CHECKED)
      {
        GetShortPathName(AppInfo.ModulePath,tmpPath,256);                                      
        strcpy(TheScript,tmpPath);
        strcat(TheScript,"bin\\upx.exe ");
    
     //options    
     if (Opts.CompressExports==1)
      {
        //strcat(TheScript,"--compress-exports=1 ");                
      }
    else
      {
        strcat(TheScript,"--compress-exports=0 ");                 
      }

    if (Opts.CompressIcons==1)
      {
        //strcat(TheScript,"--compress-icons=2 ");                
      }
    else
      {
        strcat(TheScript,"--compress-icons=0 ");                 
      }

    if (Opts.CompressResources==1)
      {
        //strcat(TheScript,"--compress-resources=1 ");                
      }
    else
      {
        strcat(TheScript,"--compress-resources=0 ");                 
      }

    if (Opts.StripRelocs==1)
      {
        //strcat(TheScript,"--strip-relocs=1 ");                
      }
    else
      {
        strcat(TheScript,"--strip-relocs=0 ");                 
      }

    



    if (Opts.CompBest==1)
      {
        strcat(TheScript,"--best ");                
      }
    else
      {
        char tmp[2];                         
        wsprintf(tmp,"%i",Opts.CompLevel);
        strcat(TheScript,"-");
        strcat(TheScript,tmp);
        strcat(TheScript," ");                           
      }                       
        
      //end options  
        
      }
    else
      {
        GetShortPathName(AppInfo.ModulePath,tmpPath,256);                                      
        strcpy(TheScript,tmpPath);
        strcat(TheScript,"bin\\upx.exe -d ");
      }
    

    strcat(TheScript,workfile);
    //ErrorBox (TheScript);
}
