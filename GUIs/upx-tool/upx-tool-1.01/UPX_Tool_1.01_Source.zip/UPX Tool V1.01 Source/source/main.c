//Copyright (C) 2005 Simon Nash

#include "globals.h"

LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

//
int WINAPI WinMain (HINSTANCE hThisInstance, HINSTANCE hPrevInstance, LPSTR lpszArgument, int nFunsterStil)
{
    MSG messages;
    
    InitCommonControls();
    strcpy(CMDLine,lpszArgument);
    FillAppInfo(hThisInstance); 
    AppInfo.MainFormWidth=544;
    AppInfo.MainFormHeight=375;
    ReadINIFile();
    LoadResourceStrings(hThisInstance);

    static HINSTANCE hRichEditDLL = 0;
    if (!hRichEditDLL) hRichEditDLL= LoadLibrary("RichEd32.dll");
    
    CheckForUPX();
    
    MyMakeClass ("WindowsApp",hThisInstance,"MAINICON",MyBackCol,WindowProcedure);
    
    hwndMainForm = CreateWindowEx (
           WS_EX_ACCEPTFILES|WS_EX_CONTROLPARENT,     
           "WindowsApp", 
           "UPX Tool",   
           WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,
           CW_USEDEFAULT,  
           CW_USEDEFAULT,   
           AppInfo.MainFormWidth,
           AppInfo.MainFormHeight,     
           HWND_DESKTOP,     
           NULL,        
           hThisInstance,    
           NULL        
           );
    oldsize=0;
    newsize=0;
    MyResizeClientArea(hwndMainForm,420,215);
    CenterWindowOnScreen(hwndMainForm);
    ShowWindow (hwndMainForm, nFunsterStil);
    
    if (Opts.AlwaysOnTop==1)
    {
    ForceWindowToTop(hwndMainForm);
    }
    
    /* Run the message loop. It will run until GetMessage() returns 0 */
    while (GetMessage (&messages, NULL, 0, 0))
    {
        /* Translate virtual-key messages into character messages */
        TranslateMessage(&messages);
        /* Send message to WindowProcedure */
        DispatchMessage(&messages);
    }   
    
}

//
LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
HDC hdc;
PAINTSTRUCT ps;
DWORD pump;
char tmpMsg[1024];
char tmpbeau[1024];

    switch (message)                  /* handle the messages */
    {
        case WM_LBUTTONUP:
            if (!mythread)
            { 
            Form_Click(LOWORD(lParam),HIWORD(lParam));
            }
            break;
        case WM_DROPFILES:
            if (!mythread)
            { 
            Form_DragDrop(wParam);
            }
            break;
        case WM_COMMAND:
             if (!mythread)
             {
             if (LOWORD(wParam)==IDC_ABOUTBUTTON)
               {
                 About_Click();
               }
             if (LOWORD(wParam)==IDC_BROWSEBUTTON)
               {
                 Browse_Click();
               }
             if (LOWORD(wParam)==IDC_GOBUTTON)
               {
                 Go_Click();
               }
             if (LOWORD(wParam)==IDC_OPTIONSBUTTON)
               {
                 Options_Click();
               }
             }  
             break;               
        case WM_CREATE:
             CreateObjects(hwnd, lParam);
             break;
        case WM_CLOSE:
             if (!mythread)
               {
                 PostQuitMessage(0);
               }
             break;
        case WM_DESTROY:
             PostQuitMessage (0);
             break;
        case WM_MAKEUPX_PROCESSCOMPLETE:
             SendMessage (GetDlgItem(hwndMainForm,IDC_PROGRESS),PBM_SETPOS,64,0); 
             CloseHandle(mythread);
             mythread=0;
             FreeConsole();

             newsize=MyGetFileSize (WorkFile);
                          
             if (newsize<oldsize)
             {
               strcpy(tmpMsg,resstr7); //"Compressed OK.  New Size Is "
               BeautifySize(newsize,tmpbeau);
               strcat(tmpMsg,tmpbeau);
               SetStatusText(tmpMsg);                   
             }

             if (newsize>oldsize)
             {
               strcpy(tmpMsg,resstr8); //"Decompressed OK.  New Size Is "
               BeautifySize(newsize,tmpbeau);
               strcat(tmpMsg,tmpbeau);
               SetStatusText(tmpMsg);                 
             }   
             
             pump=oldsize-newsize;          
             if (pump==0)
               {
                 SetStatusText(resstr9); //"No Change."
               }           
             EnableWindow(GetDlgItem(hwndMainForm,IDC_GOBUTTON),TRUE);            
             break;
        case WM_CTLCOLORSTATIC:
             return (INT) CreateSolidBrush(MyBackCol);
             break; 
        case WM_CTLCOLORBTN:
             return (INT) CreateSolidBrush(MyBackCol);
             break;
        case WM_PAINT:  
             BeginPaint(hwnd,&ps);       
             ShowLabels();
             EndPaint(hwnd,&ps);
             return DefWindowProc (hwnd, message, wParam, lParam);
             break;
        default:
             return DefWindowProc (hwnd, message, wParam, lParam);
    }
    return 0;
}

int MyMakeClass(LPSTR szClassName,HINSTANCE hInstance,LPSTR szIconName,COLORREF BackCol,WNDPROC wndproc)
{
    WNDCLASSEX wincl;
    
    wincl.hInstance = hInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = wndproc; 
    wincl.style = CS_DBLCLKS;
    wincl.cbSize = sizeof (WNDCLASSEX);
    wincl.hIcon = LoadIcon (hInstance, szIconName);
    wincl.hIconSm = LoadIcon (hInstance, "SMALLICON");
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;
    wincl.cbClsExtra = 0;
    wincl.cbWndExtra = 0;
    wincl.hbrBackground = CreateSolidBrush(BackCol);

    if (!RegisterClassEx (&wincl))
      {
        FatalError(resstr10);                               
      }
}
