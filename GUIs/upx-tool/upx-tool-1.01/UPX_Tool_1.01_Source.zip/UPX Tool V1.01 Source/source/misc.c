//Copyright (C) 2005 Simon Nash
//Credit due to NSIS team for file_exists function

#include "globals.h"

//
int CenterWindowOnScreen(HWND hwnd)
{
  RECT r1;
  int NewLeft;
  int NewTop;
  
  GetWindowRect(hwnd,&r1);
  NewLeft = (AppInfo.ScreenWidth/2) - ((r1.right-r1.left)/2);
  NewTop = (AppInfo.ScreenHeight/2) - ((r1.bottom-r1.top)/2);  

  MoveWindow (hwnd,NewLeft,NewTop,(r1.right-r1.left),(r1.bottom-r1.top),TRUE);
}

//
int FatalError(LPSTR Caption)
{
  MessageBox (hwndMainForm,Caption,APP_SHORTTITLE,MB_OK|MB_ICONSTOP);
  PostQuitMessage(0);   
}

int ErrorBox(LPSTR Caption)
{
  MessageBox (hwndMainForm,Caption,APP_SHORTTITLE,MB_OK|MB_ICONSTOP);  
}

//
int CheckForUPX()
{
  char strpath[1024];
  strcpy (strpath,AppInfo.ModulePath);
  strcat (strpath,"bin\\upx.exe");
  if (!file_exists (strpath))
    {
      FatalError (resstr11);  //"No UPX.exe found in BIN folder.  Exiting Program."             
    }
}

//
int file_exists(char *buf)
{
  HANDLE h;
  static WIN32_FIND_DATA fd;
  // Avoid a "There is no disk in the drive" error box on empty removable drives
  SetErrorMode(SEM_NOOPENFILEERRORBOX | SEM_FAILCRITICALERRORS);
  h = FindFirstFile(buf,&fd);
  SetErrorMode(0);
  if (h != INVALID_HANDLE_VALUE)
  {
    FindClose(h);
    return 1;
  }
  return 0;
}

//
int FillAppInfo(HINSTANCE hInstance)
{
  int L1;
  //Screen Size
  AppInfo.ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
  AppInfo.ScreenHeight = GetSystemMetrics(SM_CYSCREEN); 
  
  //Application Path
  GetModuleFileName(NULL,MFPBuf,1024);
  AppInfo.ModuleFullPath = MFPBuf;
  AppInfo.ModuleName = strrchr(MFPBuf,'\\')+1;
  L1 = strlen(AppInfo.ModuleFullPath)-strlen(AppInfo.ModuleName);
  strncpy(MPBuf,MFPBuf,L1);
  MPBuf[L1]='\0';
  AppInfo.ModulePath=MPBuf;
  AppInfo.hInstance=hInstance;
  //ErrorBox(AppInfo.ModulePath);
}

int MyResizeClientArea(HWND hwnd,int NewClientWidth,int NewClientHeight)
{
    RECT r;
    RECT r2;
    GetWindowRect(hwnd,&r);
    GetClientRect(hwnd,&r2);
    
    AppInfo.MainFormWidth = NewClientWidth+((r.right-r.left)-(r2.right-r2.left));
    AppInfo.MainFormHeight = NewClientHeight+((r.bottom-r.top)-(r2.bottom-r2.top));
        
    MoveWindow 
      (
      hwnd,
      r.left,
      r.top,
      NewClientWidth+((r.right-r.left)-(r2.right-r2.left)),
      NewClientHeight+((r.bottom-r.top)-(r2.bottom-r2.top)),
      TRUE
      );                    
}

int ShowLabels()
{
LOGFONT lf;
HDC frmDC;
HFONT frmFont;

SystemParametersInfo(SPI_GETICONTITLELOGFONT, sizeof(lf), &lf, 0);
frmDC=GetDC(hwndMainForm);
lf.lfHeight = -MulDiv(10, GetDeviceCaps(frmDC, LOGPIXELSY), 72);
lf.lfWeight = 300;
strcpy(lf.lfFaceName,"Courier New");  
frmFont = CreateFontIndirect (&lf); 
SetTextColor(frmDC,MyColWhite);
SelectObject(frmDC,frmFont);
SetBkMode(frmDC,TRANSPARENT);
TextOut(frmDC,35,115,"Compress",8);
TextOut(frmDC,35,138,"Decompress",10);
TextOut(frmDC,195,10,resstr1,19);//"Ultimate EXE Packer"
TextOut(frmDC,195,25,resstr2,25);//"GUI Version by Simon Nash"
TextOut(frmDC,195,40,resstr3,20);//"V1.01 Copyright 2005"
TextOut(frmDC,10,195,StatusMsg,strlen(StatusMsg));
ReleaseDC(hwndMainForm,frmDC);
}

DWORD MyGetFileSize(LPSTR file)
{
HANDLE FileHandle;
DWORD lowo;
DWORD higho;
DWORD filesize;
FileHandle=CreateFile (file,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
higho=0;
lowo=GetFileSize(FileHandle,&higho);	 

if (higho == 0) 
  {
  filesize=lowo;
  }
else
  {
  ErrorBox(resstr12);//"File Too Big"
  }
//wsprintf(tmpo,"%d",filesize);
CloseHandle(FileHandle);
return filesize;
}

int SetStatusText(LPSTR OutText)
{
RECT r;
strcpy(StatusMsg,OutText);
r.left=10;
r.right=410;
r.top=195;
r.bottom=215;
InvalidateRect(hwndMainForm,&r,TRUE); 
}

LPSTR BeautifySize(DWORD filesaz,LPSTR buf)
{
float filesize;
char tmpo[1024];

filesize=(FLOAT)filesaz;

if (filesize>1024)
  {
    filesize=filesize/1024;
      if (filesize>1024)
        {
          filesize=filesize/1024;
          sprintf(tmpo,"%1.2f",filesize);
          strcat(tmpo," MB.");
        } 
      else
        {
          sprintf(tmpo,"%1.0f",filesize);
          strcat(tmpo," KB.");
        }
  }
else
  {
    wsprintf(tmpo,"%4.4f",filesize);
    strcat(tmpo," Bytes.");
  }
strcpy(buf,tmpo);   
}

int LoadResourceStrings(HINSTANCE hInstance)
{
LoadString(hInstance,8001,resstr1,1024);
LoadString(hInstance,8002,resstr2,1024);
LoadString(hInstance,8003,resstr3,1024);
LoadString(hInstance,8004,resstr4,1024);
LoadString(hInstance,8005,resstr5,1024);
LoadString(hInstance,8006,resstr6,1024);
LoadString(hInstance,8007,resstr7,1024);
LoadString(hInstance,8008,resstr8,1024);
LoadString(hInstance,8009,resstr9,1024);
LoadString(hInstance,8010,resstr10,1024);
LoadString(hInstance,8011,resstr11,1024);
LoadString(hInstance,8012,resstr12,1024);
LoadString(hInstance,8013,resstr13,1024);
LoadString(hInstance,8014,resstr14,1024);
LoadString(hInstance,8015,resstr15,1024);
}

int ForceWindowToTop(HWND hwnd)
{
SetWindowPos(hwnd,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);    
}

int UnForceWindowToTop(HWND hwnd)
{
SetWindowPos(hwnd,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);    
}	
