//Copyright (C) 2005 Simon Nash

#include "globals.h"


BOOL CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)                  /* handle the messages */
    {
        case WM_INITDIALOG:
              CenterWindowOnScreen(hwndDlg);
              if (Opts.CompressExports==1)
                {
                SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPRESSEXPORTS),BM_SETCHECK, 1,0);
                }
                
              if (Opts.CompressIcons==1)
                {
                SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPRESSICONS),BM_SETCHECK, 1,0);
                }
                
              if (Opts.CompressResources==1)
                {
                SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPRESSRESOURCES),BM_SETCHECK, 1,0);
                }
                
              if (Opts.StripRelocs==1)
                {
                SendMessage(GetDlgItem(hwndDlg,IDC_DLGSTRIPRELOCS),BM_SETCHECK, 1,0);
                }


                {
                SendMessage(GetDlgItem(hwndDlg,IDC_DLGTRACKER),TBM_SETPOS, TRUE,Opts.CompLevel);
                } 
                
              if (Opts.CompBest==1)
                {
                SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPBEST),BM_SETCHECK, 1,0);
                EnableWindow(GetDlgItem(hwndDlg, IDC_DLGTRACKER),0);
                SetWindowText(GetDlgItem(hwndDlg,IDC_DLGLEVELLABEL),"Level : Best");
                }  
              else
                {
                  char tmplev[25];
                  wsprintf(tmplev,"Level : %i",Opts.CompLevel);
                  strcat(tmplev,"     ");
                  SetWindowText(GetDlgItem(hwndDlg,IDC_DLGLEVELLABEL),tmplev);                                                           
                }

              if (Opts.AlwaysOnTop==1)
                {
                SendMessage(GetDlgItem(hwndDlg,IDC_DLGALWAYSONTOP),BM_SETCHECK, 1,0);
                } 

              if (Opts.AutoStart==1)
                {
                SendMessage(GetDlgItem(hwndDlg,IDC_DLGAUTOSTART),BM_SETCHECK, 1,0);
                }
                
              if (Opts.ShowConsole==1)
                {
                SendMessage(GetDlgItem(hwndDlg,IDC_DLGSHOWCONSOLE),BM_SETCHECK, 1,0);
                }
                                               
                SendMessage(GetDlgItem(hwndDlg,IDC_DLGTRACKER),TBM_SETRANGE,TRUE,(LPARAM) MAKELONG(1, 9));

            break;
        case WM_COMMAND:
            if (LOWORD(wParam)==IDC_DLGOK)
               {
                 Opts.CompressExports=SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPRESSEXPORTS),BM_GETCHECK,0,0);
                 Opts.CompressIcons=SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPRESSICONS),BM_GETCHECK,0,0);
                 Opts.CompressResources=SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPRESSRESOURCES),BM_GETCHECK,0,0);
                 Opts.StripRelocs=SendMessage(GetDlgItem(hwndDlg,IDC_DLGSTRIPRELOCS),BM_GETCHECK,0,0);
                 Opts.CompBest=SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPBEST),BM_GETCHECK,0,0);
                 Opts.CompLevel=SendMessage(GetDlgItem(hwndDlg,IDC_DLGTRACKER),TBM_GETPOS,0,0);
                 Opts.AlwaysOnTop=SendMessage(GetDlgItem(hwndDlg,IDC_DLGALWAYSONTOP),BM_GETCHECK,0,0);    
                 Opts.AutoStart=SendMessage(GetDlgItem(hwndDlg,IDC_DLGAUTOSTART),BM_GETCHECK,0,0); 
                 Opts.ShowConsole=SendMessage(GetDlgItem(hwndDlg,IDC_DLGSHOWCONSOLE),BM_GETCHECK,0,0); 
                 SaveINIFile();
                 EnableWindow(hwndMainForm,1);
                 if (Opts.AlwaysOnTop==1)
                   {
                     ForceWindowToTop(hwndMainForm);
                   }
                 else
                   {
                   UnForceWindowToTop(hwndMainForm);  
                   }                       
                 DestroyWindow(hwndDlg);
               }
            if (LOWORD(wParam)==IDC_DLGCANCEL)
               {
                 EnableWindow(hwndMainForm,1);                         
                 DestroyWindow(hwndDlg);                 
               }
            if (LOWORD(wParam)==IDC_DLGCOMPBEST)
               {
                                                
                 if (SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPBEST),BM_GETCHECK,0,0)==1)
                  {
                    SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPBEST),BM_SETCHECK, 1,0);
                    EnableWindow(GetDlgItem(hwndDlg, IDC_DLGTRACKER),0);
                    SetWindowText(GetDlgItem(hwndDlg,IDC_DLGLEVELLABEL),"Level : Best");
                  }  
                 else
                  {
                    char tmplev[25];
                    wsprintf(tmplev,"Level : %i",SendMessage(GetDlgItem(hwndDlg,IDC_DLGTRACKER),TBM_GETPOS,0,0));
                    strcat(tmplev,"     ");
                    SetWindowText(GetDlgItem(hwndDlg,IDC_DLGLEVELLABEL),tmplev);                                                           
                  }                                 
                                                
                                                
                                                
                 EnableWindow(GetDlgItem(hwndDlg,IDC_DLGTRACKER),1-(SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPBEST),BM_GETCHECK,0,0)));                                         
               }
            break;
            
        case WM_HSCROLL:
            if (((HWND) lParam)==(GetDlgItem(hwndDlg, IDC_DLGTRACKER)))
            {     
                 if (SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPBEST),BM_GETCHECK,0,0)==1)
                  {
                    SendMessage(GetDlgItem(hwndDlg,IDC_DLGCOMPBEST),BM_SETCHECK, 1,0);
                    EnableWindow(GetDlgItem(hwndDlg, IDC_DLGTRACKER),0);
                    SetWindowText(GetDlgItem(hwndDlg,IDC_DLGLEVELLABEL),"Level : Best");
                  }  
                 else
                  {
                    char tmplev[25];
                    wsprintf(tmplev,"Level : %i",SendMessage(GetDlgItem(hwndDlg,IDC_DLGTRACKER),TBM_GETPOS,0,0));
                    strcat(tmplev,"     ");
                    SetWindowText(GetDlgItem(hwndDlg,IDC_DLGLEVELLABEL),tmplev);                                                           
                  }  
            }     
            break;
        case WM_CLOSE:
               EnableWindow(hwndMainForm,1);                         
               DestroyWindow(hwndDlg);             
            break;
    }
    return 0;     
}
