//Copyright (C) 2005 Simon Nash

#include "globals.h"

//
int CreateObjects(HWND hwndOwner, LPARAM lParam)
{
  HWND tmphwnd;
  //LPSTR tmpstr;
  char tmpstr2[1024];
  LPSTR dufus;
  tmphwnd = CreateWindowEx (
    0,
    "STATIC",
    "TITLEBMP",
    WS_VISIBLE|WS_CHILD|SS_BITMAP,
    10,  10,  175,  56,
    hwndOwner,
    (HMENU) IDC_MAINBMP,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );

  tmphwnd = CreateWindowEx (
    0,
    "STATIC",
    "",
    WS_VISIBLE|WS_CHILD|SS_WHITEFRAME,
    10,  110,  120,  50,
    hwndOwner,
    (HMENU) IDC_FRAME1,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );

  tmphwnd = CreateWindowEx (
    0,
    "BUTTON",
    "",
    WS_VISIBLE|WS_CHILD|BS_AUTORADIOBUTTON,
    15,  111,  15,  24,
    hwndOwner,
    (HMENU) IDC_OPTCOMP,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  SendMessage(tmphwnd,BM_SETCHECK, 1,0);
  objChangeFont(hwndOwner,tmphwnd,"Courier New",10,0);
  
  tmphwnd = CreateWindowEx (
    0,
    "BUTTON",
    "",
    WS_VISIBLE|WS_CHILD|BS_AUTORADIOBUTTON,
    15,  135,  15,  24,
    hwndOwner,
    (HMENU) IDC_OPTDECOMP,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  objChangeFont(hwndOwner,tmphwnd,"Courier New",10,0);

  tmphwnd = CreateWindowEx (
    WS_EX_CLIENTEDGE,
    "EDIT",
    "{FILENAME AND PATH HERE}",
    WS_VISIBLE|WS_CHILD|ES_LEFT|ES_AUTOHSCROLL,
    10,  80,  370,  22,
    hwndOwner,
    (HMENU) IDC_FILEEDIT,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  objChangeFont(hwndOwner,tmphwnd,"Courier New",10,0);
  if (!CMDLine[0]==0)
  {
  strncpy(tmpstr2,CMDLine,strlen(CMDLine)-1);
  tmpstr2[strlen(CMDLine)-1]=0;
  dufus=strchr(tmpstr2,'"')+1;
  SetWindowText (tmphwnd,dufus);  
  }
  
  
  tmphwnd = CreateWindowEx (
    0,
    "BUTTON",
    "...",
    WS_VISIBLE|WS_CHILD,
    385,  80,  25,  22,
    hwndOwner,
    (HMENU) IDC_BROWSEBUTTON,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  
  tmphwnd = CreateWindowEx (
    0,
    "BUTTON",
    "Options",
    WS_VISIBLE|WS_CHILD,
    310,  110,  100,  22,
    hwndOwner,
    (HMENU) IDC_OPTIONSBUTTON,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  objChangeFont(hwndOwner,tmphwnd,"Courier New",10,0);
    
  tmphwnd = CreateWindowEx (
    0,
    "BUTTON",
    "About",
    WS_VISIBLE|WS_CHILD,
    310,  138,  100,  22,
    hwndOwner,
    (HMENU) IDC_ABOUTBUTTON,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  objChangeFont(hwndOwner,tmphwnd,"Courier New",10,0);
    
  tmphwnd = CreateWindowEx (
    0,
    "BUTTON",
    "GO!",
    WS_VISIBLE|WS_CHILD,
    140,  110,  160,  50,
    hwndOwner,
    (HMENU) IDC_GOBUTTON,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  );
  objChangeFont(hwndOwner,tmphwnd,"Courier New",22,1);
  
  tmphwnd = CreateWindowEx (
    WS_EX_CLIENTEDGE,
    "msctls_progress32",
    "",
    WS_CHILD|WS_VISIBLE,
    10,  170,  400,  15,
    hwndOwner,
    (HMENU) IDC_PROGRESS,
    ((LPCREATESTRUCT) lParam)->hInstance,
    NULL
  ); 
  SendMessage (tmphwnd,PBM_SETRANGE,0,MAKELPARAM(0, 64));
  
}
