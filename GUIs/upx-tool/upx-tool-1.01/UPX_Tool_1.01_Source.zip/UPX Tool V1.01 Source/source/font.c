//Copyright (C) 2005 Simon Nash

#include "globals.h"

//
int objChangeFont(HWND hwndForm, HWND hwndObj, LPSTR strFace, int fontsize, int fontbold)
{
LOGFONT lf;
HDC frmDC;

SystemParametersInfo(SPI_GETICONTITLELOGFONT, sizeof(lf), &lf, 0);
frmDC=GetDC(hwndForm);
lf.lfHeight = -MulDiv(fontsize, GetDeviceCaps(frmDC, LOGPIXELSY), 72);

if (fontbold==0)
  {
    lf.lfWeight = 300;
  }
else
  {
    lf.lfWeight = 700;
  }

strcpy(lf.lfFaceName,strFace);  
SendMessage(hwndObj,WM_SETFONT, (WPARAM)CreateFontIndirect (&lf), MAKELPARAM(TRUE, 0));
}
