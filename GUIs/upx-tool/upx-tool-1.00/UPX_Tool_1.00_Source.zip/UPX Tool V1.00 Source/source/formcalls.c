//Copyright (C) 2005 Simon Nash

#include "globals.h"

//
int Go_Click()
{
  char tmpPath[1024];   
  DWORD retval;

  EnableWindow(GetDlgItem(hwndMainForm,IDC_GOBUTTON),FALSE);
  GetWindowText(GetDlgItem(hwndMainForm,IDC_FILEEDIT) , WorkFile,512);

  SetStatusText("Working...");

  oldsize=MyGetFileSize (WorkFile);
  
  retval=GetShortPathName(WorkFile,tmpPath,255);
    if (!file_exists(tmpPath))
      {
        EnableWindow(GetDlgItem(hwndMainForm,IDC_GOBUTTON),TRUE);
        
        SetStatusText("File Not Found.");
        return;  
      }
     
    BuildCmd(tmpPath);         
    //SetDlgItemText(hwndMainForm, IDC_LOGWIN, "");

    DWORD id;
    mythread=CreateThread(NULL,0,CompressThread,0,0,&id);

}
//
int About_Click()
{

}

//
int Options_Click()
{

}

//
int Browse_Click()
{
  char ODLGBuf[1024];
  OPENFILENAME lpofn={sizeof(lpofn),};
  DWORD retval;
  
  lpofn.hwndOwner = hwndMainForm;
  lpofn.lpstrFilter = "EXE Files\0*.exe\0All Files\0*.*\0";
  lpofn.lpstrFile = ODLGBuf;
  lpofn.nMaxFile = 1023;
  lpofn.lpstrTitle = "Open EXE File";
  lpofn.lpstrDefExt = "exe";
  lpofn.lpstrInitialDir = NULL;
  lpofn.Flags = OFN_HIDEREADONLY|OFN_EXPLORER|OFN_PATHMUSTEXIST;
                 
  ODLGBuf[0]=0;                    
  retval=GetOpenFileName(&lpofn);
    if (retval!=0)
      {
        SetWindowText(GetDlgItem(hwndMainForm,IDC_FILEEDIT),ODLGBuf);
      }
}

//
int Form_DragDrop(WPARAM wParam)
{
  HANDLE hDrop;
  char Dragged[1024];
  
  hDrop = (HANDLE) wParam; 
  DragQueryFile(hDrop,0,Dragged,1024);
  DragFinish (hDrop);
  SetWindowText (GetDlgItem(hwndMainForm,IDC_FILEEDIT),Dragged);
}

int Form_Click(int xPos,int yPos)
{
  if (xPos>35)
    {
      if (yPos>115)
        {
          if (xPos<100)
            {
              if (yPos<138)
                {
                  SendMessage(GetDlgItem(hwndMainForm,IDC_OPTCOMP),BM_SETCHECK, 1,0);
                  SendMessage(GetDlgItem(hwndMainForm,IDC_OPTDECOMP),BM_SETCHECK, 0,0);           
                }
            }
        }  
    }  
    
  if (xPos>35)
    {
      if (yPos>138)
        {
          if (xPos<120)
            {
              if (yPos<161)
                {
                  SendMessage(GetDlgItem(hwndMainForm,IDC_OPTDECOMP),BM_SETCHECK, 1,0);
                  SendMessage(GetDlgItem(hwndMainForm,IDC_OPTCOMP),BM_SETCHECK, 0,0);           
                }
            }
        }  
    }  
}
