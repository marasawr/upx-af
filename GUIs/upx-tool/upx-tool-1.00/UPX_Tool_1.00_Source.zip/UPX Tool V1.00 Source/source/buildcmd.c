//Copyright (C) 2005 Simon Nash

#include "globals.h"

//
int BuildCmd(LPSTR workfile)
{
  int Opt1Val;
  DWORD retval;
  char tmpPath[1024]; 
    
  Opt1Val=SendMessage(GetDlgItem(hwndMainForm,IDC_OPTCOMP),BM_GETCHECK,0,0);
              
    if (Opt1Val==BST_CHECKED)
      {
        GetShortPathName(AppInfo.ModulePath,tmpPath,256);                                      
        strcpy(TheScript,tmpPath);
        strcat(TheScript,"bin\\upx.exe ");
      }
    else
      {
        GetShortPathName(AppInfo.ModulePath,tmpPath,256);                                      
        strcpy(TheScript,tmpPath);
        strcat(TheScript,"bin\\upx.exe -d ");
      }
              
    strcat(TheScript,workfile);
}
