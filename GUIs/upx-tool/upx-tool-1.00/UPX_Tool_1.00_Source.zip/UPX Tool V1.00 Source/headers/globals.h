//Copyright (C) 2005 Simon Nash

#include <windows.h>
#include <richedit.h>
#include <commctrl.h>
#include <commdlg.h>
#include <winuser.h>

#define WM_MAKEUPX_PROCESSCOMPLETE (WM_USER+1001)

#define mdCompress   0
#define mdDecompress 1

#define APP_SHORTTITLE "UPX"
#define APP_LONGTITLE  "UPX Tool"

#define IDC_MAINBMP         7001
#define IDC_FRAME1          7002
#define IDC_OPTCOMP         7003
#define IDC_OPTDECOMP       7004
#define IDC_FILEEDIT        7005
#define IDC_BROWSEBUTTON    7006
#define IDC_ABOUTBUTTON     7007
#define IDC_OPTIONSBUTTON   7008
#define IDC_GOBUTTON        7009
#define IDC_PROGRESS        7010

#define MyColWhite RGB(255,255,255)
#define MyColBlack RGB(0,0,0)
#define MyColRed RGB(255,0,0)
#define MyColGreen RGB(0,255,0)
#define MyColBlue RGB(0,0,255)

#define MyBackCol RGB(0,0,66)

typedef struct AppInfoType {
  LPSTR ModuleFullPath;
  LPSTR ModuleName;
  LPSTR ModulePath;
  int ScreenWidth;
  int ScreenHeight;
  int MainFormWidth;
  int MainFormHeight;
} NAPPINFOTYPE;

NAPPINFOTYPE AppInfo;

HWND hwndMainForm;
HANDLE mythread;
HANDLE con_out;

char MFPBuf[1024];
char MPBuf[1024];
char TheScript[1024];
char StatusMsg[1024];

char WorkFile[1024];
DWORD oldsize;
DWORD newsize;

char CMDLine[1024];

DWORD WINAPI CompressThread (LPVOID p);
int ErrorBox(LPSTR Caption);
